#!/bin/sh

export LD_PRELOAD=/usr/lib/libcofi_rpi.so
